# writersgarage.net — Static Mirror (GitHub Actions + Netlify)

This repo uses a GitHub Action to **crawl `https://writersgarage.net/`**, save a **static copy** into the `public/` folder, and commit it. Connect the repo to **Netlify** and set `public` as the **Publish directory**.

> You confirmed you own writersgarage.net. If you later mirror other domains, make sure you have permission.

## How to use (browser only)

1. Create a new GitHub repo (e.g., `writersgarage-mirror`).
2. Upload these files to the repo (keep the same structure).
3. Go to the **Actions** tab → select **Mirror writersgarage.net** → **Run workflow**.
4. After it finishes, open the repo → you’ll see the `public/` folder with your static copy.
5. On **Netlify** → **Add new site** → **Import from Git** → pick this repo → set **Publish directory** to `public` → Deploy.

### Notes
- The mirror is static. Dynamic features (forms, login, cart, search) won’t work unless you replace them with a backend (e.g., Netlify Functions/Forms).
- The Action runs on a schedule by default (weekdays 02:00 UTC). You can edit or remove the cron in `.github/workflows/mirror.yml`.
- If the site references external assets (Google Fonts, CDNs), those will still load from their external hosts. You can extend the `wget` command with `--span-hosts` and a `--domains=` list if you want to **download** those assets locally.

## Optional: SPA fallback / redirects
For most mirrored WordPress sites you don’t need redirects. If you do want a single-page fallback, add a `_redirects` file and set:
```
/*   /index.html   200
```
Commit and deploy again.
